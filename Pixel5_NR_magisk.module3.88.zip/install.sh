SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=false

LATESTARTSERVICE=false

  ui_print "Module installation is complete."
  ui_print "************************************"
  ui_print "             Pixel 5 "
  ui_print "           *NR Unlock* "
  ui_print "Thank you for choosing this module"
  ui_print "************************************"
  ui_print "Start deleting radio cache."
  ui_print "Start deleting /data/vendor/radio"
rm -r /data/vendor/radio
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/modem_fdr…"
rm -r /data/vendor/modem_fdr
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/iccid_0…"
rm /data/vendor/radio/iccid_0
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/qcril.db"
rm /data/vendor/radio/qcril.db
  ui_print "Execution complete!"
  ui_print "Start deleting /data/vendor/radio/qcril_backup.db"
rm /data/vendor/radio/qcril_backup.db
  ui_print "Execution complete!"
  ui_print "Start to complete the final debugging..."

REPLACE="
/vendor/rfs/msm/mpss/readonly/vendor/mbn/mcfg_sw
/system/vendor/rfs/msm/mpss/readonly/vendor/mbn/mcfg_sw
"

on_install() {
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  }
  ui_print "- Parameter compiling"
  
  set_permissions() {
  set_perm_recursive $MODPATH/system/vendor/mbn 0 0 0755 0644 u:object_r:vendor_file:s0
  set_perm_recursive $MODPATH 0 0 0755 0644 u:object_r:vendor_file:s0
}
  ui_print "- Try to execute the settings put global captive_portal_mode 0 command"
  settings put global captive_portal_mode 0

  ui_print "fully completed"
  ui_print "__________________________________"
  ui_print "I need your donation. The following is the module usage tutorial"
  ui_print "----------------------------------------------"
  ui_print "|If the network is abnormal after restarting,|"
  ui_print "|please try to fix it through this tutorial: |"
  ui_print "|After the installation is complete, please  |"
  ui_print "|restart, and then connect to the computer,  |"
  ui_print "|enter:    adb shell                         |"
  ui_print "|and then enter:                             |"
  ui_print "|settings put global captive_portal_mode 0,  |"
  ui_print "|after executing the command, all functions  |"
  ui_print "|can be used normally.                       |"
  ui_print "----------------------------------------------"
