#!/system/bin/sh

  ui_print "************************************"
  ui_print " Enabling VoLTE/VoWiFi/RCS settings "
  ui_print "************************************"