A Magisk module (in testing) to enable 5G for Unlisted Countries, VoLTE switches in the settings and add support for more countries/carriers.

VoLTE still won't work if there is no specific VoTLE mbn file for your carrier.

----------------------------------------------------------
Download from "Releases" and flash in magisk manager.

----------------------------------------------------------
